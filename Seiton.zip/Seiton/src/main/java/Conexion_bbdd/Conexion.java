package Conexion_bbdd;

import Vistas.InicioSesion;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

/* @author Samuel Chamizo González*/

public class Conexion {
    
    private static Connection con;
    private static final String driver="com.mysql.jdbc.Driver";
    private static final String user="Mf7qO3TN9q";
    private static final String pass="2BSHn460hl";
    private static final String url="jdbc:mysql://remotemysql.com:3306/Mf7qO3TN9q";
    private static Statement st;

    //Conecta con la base de datos
    public static void conectar() 
    {
        // Reseteamos a null la conexion a la bd
        con=null;
        try
        {
            Class.forName(driver);
            // Nos conectamos a la bd
            con= (Connection) DriverManager.getConnection(url, user, pass);
        }
        // Si la conexion NO fue exitosa mostramos un mensaje de error
        catch (ClassNotFoundException | SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Error de conexion con la base de datos");
        }
    }
    
    //Elimina la conexión con la base de datos
    public static void desconectar() 
    {
        con=null;
    }
    
    //Consulta que develve 1 solo valor
    public static String consultaValor(String valorBuscado,String consulta)throws SQLException {
        
        //Variable que retornaremos al finalizar la función
        String resultado="";
        //Conecta con la base de datos.
        conectar();
        /*Crea la declaración*/
        Statement statement = con.createStatement();
        //Guarda el resultado del selectTableSQL en la variable rs 
        ResultSet rs = statement.executeQuery(consulta);
        //Recorre y lee los resultados 
        if (rs.next())
        {
            resultado=rs.getString(valorBuscado);
        }
        desconectar();
        return resultado;
    }
    
    //Devuelve una matriz con la información de 1as actividades a la espera de compartirse
    public static String [][] consultaTareasEsperando(String usuario)throws SQLException {
        //Variable que retornaremos al finalizar la función¡
        String [][] resultado = new String [100][7];
        //Conecta con la base de datos.
        conectar();
        /*Crea la declaración*/
        Statement statement = con.createStatement();
        //Guarda el resultado del selectTableSQL en la variable rs 
        ResultSet rs = statement.executeQuery("SELECT * FROM Actividades where Compartido_estado='Esperando' and Compartido_con='"+usuario+"'" );

        //Recorre y guarda los resultados en un array 
        int i=0;
        while (rs.next())
        {
            resultado[i][0]=rs.getString("id");
            resultado[i][1]=rs.getString("Nombre");
            resultado[i][2]=rs.getString("Fecha_realizacion");
            resultado[i][3]=rs.getString("Hora_realizacion");
            resultado[i][4]=rs.getString("Compartido_estado");
            resultado[i][5]=rs.getString("Compartido_con");
            resultado[i][6]=rs.getString("Compartido_por");
            i++;
        }
        
        desconectar();
        return resultado;
    }
    
    //Devuelve una matriz con la información de 1as actividades compartidas
    public static String [][] consultaActividadesCompartidas(int ano, int mes, String usuario) {
        //Variable que retornaremos al finalizar la función
        String[][] resultado = new String[93][12];
        try {
            //Conecta con la base de datos.
            conectar();
            /*Crea la declaración*/
            Statement statement = con.createStatement();
            //Guarda el resultado del selectTableSQL en la variable rs 
            ResultSet rs = statement.executeQuery("SELECT * FROM Actividades where Fecha_realizacion>='" + ano + "-" + mes + "-01' AND Fecha_realizacion<'" + ano + "-" + (mes + 1) + "-01' AND Compartido_estado= 'Compartido' AND Compartido_con ='" + usuario + "'");
            
            //Recorre y guarda los resultados en una matriz
            int i = 0;
            while (rs.next()) {
                resultado[i][0] = rs.getString("id");
                resultado[i][1] = rs.getString("Nombre");
                resultado[i][2] = rs.getString("Fecha_creacion");
                resultado[i][3] = rs.getString("Fecha_realizacion");
                resultado[i][4] = rs.getString("Hora_realizacion");
                resultado[i][5] = rs.getString("Prioridad");
                resultado[i][6] = rs.getString("Categoria");
                resultado[i][7] = rs.getString("Comentario");
                resultado[i][8] = rs.getString("Usuario");
                resultado[i][9] = rs.getString("Compartido_estado");
                resultado[i][10] = rs.getString("Compartido_con");
                resultado[i][11] = rs.getString("Compartido_por");
                i++;
            }
            
        } catch (SQLException e) {
            System.err.println(e);
        }
        
        desconectar();
        return resultado;
    }
    
    //Devuelve una matriz con la información de 1a actividades de un mes en concreto
    public static String [][] consultaActividadesMes(int ano, int mes, String usuario)throws SQLException {
        //Variable que retornaremos al finalizar la función
        String [][] resultado = new String [93][12];
        //Conecta con la base de datos.
        conectar();
        /*Crea la declaración*/
        Statement statement = con.createStatement();
        //Guarda el resultado del selectTableSQL en la variable rs 
        ResultSet rs = statement.executeQuery("SELECT * FROM Actividades where Usuario='"+usuario+"' AND Fecha_realizacion>='"+ano+"-"+mes+"-01' AND Fecha_realizacion<'"+ano+"-"+(mes+1)+"-01'");
        
        //Recorre y guarda los resultados en un array 
        int i=0;
        while (rs.next())
        {
            resultado[i][0]=rs.getString("id");
            resultado[i][1]=rs.getString("Nombre");
            resultado[i][2]=rs.getString("Fecha_creacion");
            resultado[i][3]=rs.getString("Fecha_realizacion");
            resultado[i][4]=rs.getString("Hora_realizacion");
            resultado[i][5]=rs.getString("Prioridad");
            resultado[i][6]=rs.getString("Categoria");
            resultado[i][7]=rs.getString("Comentario");
            resultado[i][8]=rs.getString("Usuario");
            resultado[i][9]=rs.getString("Compartido_estado");
            resultado[i][10]=rs.getString("Compartido_con");
            resultado[i][11]=rs.getString("Compartido_por");
            i++;
        }
        desconectar();
        return resultado;
    }
    
    //Devuelve un vector con la información de un usuario
    public static String [] consultaValoresUsuario(String usuario)throws SQLException {
        //Variable que retornaremos al finalizar la función
        String [] resultado = new String [4];
        //Conecta con la base de datos.
        conectar();
        /*Crea la declaración*/
        Statement statement = con.createStatement();
        //Guarda el resultado del selectTableSQL en la variable rs 
        ResultSet rs = statement.executeQuery("SELECT Nombre, Primer_apellido, Segundo_apellido, Correo FROM Usuario where Nombre_usuario='"+usuario+"'");
        //Recorre y guarda los resultados en un array 
        while (rs.next())
        {
            resultado[0]=rs.getString("Nombre");
            resultado[1]=rs.getString("Primer_apellido");
            resultado[2]=rs.getString("Segundo_apellido");
            resultado[3]=rs.getString("Correo");
        }
        desconectar();
        return resultado;
    }
    
    //Devuelve un vector con los nombres de usuario que existen
    public static String [] consultaUsuarios()throws SQLException {
        //Variable que retornaremos al finalizar la función
        String [] resultado = new String [1000];
        //Conecta con la base de datos.
        conectar();
        /*Crea la declaración*/
        Statement statement = con.createStatement();
        //Guarda el resultado del selectTableSQL en la variable rs 
        ResultSet rs = statement.executeQuery("SELECT Nombre_usuario FROM Usuario");
        //Recorre y guarda los resultados en un array 
        int i=0;
        while (rs.next())
        {
            resultado[i]=rs.getString("Nombre_usuario");
            i++;
        }
        desconectar();
        return resultado;
    }
    
    //Introduce o elimina datos en la base de datos
    public static void update_delete(String consulta)throws SQLException
    {
        //Conecta con la base de datos.
        conectar();
        //Declara una variable de la que se espera un valor de retorno
        Statement statement = con.createStatement();
        //Guarda la consulta
        statement.executeUpdate(consulta);
        desconectar();
    }
    
    //Sube la imagen a la base de datos
    public static void subeImagen(String ruta)throws SQLException
    {
        //Conecta con la base de datos
        conectar();
        //
	FileInputStream fis = null;
	PreparedStatement ps = null;
        
	try {
		con.setAutoCommit(false);
		File file = new File(ruta);
		fis = new FileInputStream(file);
                
                InputStream in = new FileInputStream(ruta); //Contiene la imagen
		ps = con.prepareStatement("update Usuario set imagen = (?) where Nombre_usuario='"+InicioSesion.nombreUsuario+"'"); 
                ps.setBlob(1, in);  //Le dice el tipo de campo que es y lo que contiene.
		ps.executeUpdate(); //Ejecuta la sentencia SQL
                
		con.commit();   //Realiza todos los cambios efectuados desde la confirmación anterior
                
	} catch (Exception ex) {
                System.err.println(ex);
	}finally{
            try {
                    //Cierra la conexion con las clases
                    ps.close();
                    fis.close();
            } catch (Exception ex) {
                System.err.println(ex);
            }
	}  
        desconectar(); 
    }  
    
    //Consulta la imagen a la base de datos
    public static Image consultaImagen()throws SQLException
    {
        Image imagen=null;
        conectar();
        st = con.createStatement();
        
	try {
            //Variable que guarda el resultado de la sentencia SQL
            ResultSet rs = st.executeQuery("SELECT Imagen FROM Usuario where Nombre_usuario='"+InicioSesion.nombreUsuario+"'"); 
            //Recorre los valores encontrados
            if (rs.next())
            {
                Blob blob = rs.getBlob("Imagen"); //Guarda la imagen en una variable ttipo Blob
                byte[] data = blob.getBytes(1, (int)blob.length()); //Se convierte a byte
                BufferedImage img = ImageIO.read(new ByteArrayInputStream(data)); //Se guarda en un BufferedImage
                imagen=img;
            }
            rs.close();
	} catch (Exception ex) {
            System.err.println(ex);
	}
        desconectar();
	return imagen;
    }
}
