package Vistas;

import Logica.logica;
import Conexion_bbdd.Conexion;
import static Conexion_bbdd.Conexion.consultaActividadesCompartidas;
import static Conexion_bbdd.Conexion.consultaActividadesMes;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import static java.awt.Frame.HAND_CURSOR;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/* @author Samuel Chamizo González*/

public class PanelCalendario extends javax.swing.JPanel {
    
    private int total_actividades_mes=0; //Total de actividades en el calendario
    private int total_act_compartidas_mes=0; //Total de actividades en el calendario
    private HashMap paneles = new HashMap<String,JPanel>(); //Guarda los paneles
    //private HashMap labels = new HashMap<String,JLabel>(); //Guarda los labels
    private HashMap botones = new HashMap<String,JButton>(); //Guarda los botones del mes seleccionado
    private String [][] actividades_propias = new String [93][12]; //Guarda las actividades propias del mes seleccionado
    private String [][] actividades_compartidas = new String [93][12]; //Guarda las actividades compartidas del mes seleccionado
    private String [][] total_actividades=new String [93][12]; //Guarda las actividades totales del mes seleccionado
    private int mes_actual;
    private int ano_actual;
    private boolean hayNotificacion=false;
    TareasPendientes tp_Frame =new TareasPendientes();
    
    public PanelCalendario() {
        initComponents();
        
        //Oculta el panel de la actividad.
        panel_actividad.setVisible(false);
        
        //Pone nombres a los paneles para despues acceder a ellos mediante su nombre.
        poneNombresPaneles();
        
        //Cambia el puntero cuando pasa por encima del objeto.
        label_lupa.setCursor(new Cursor(HAND_CURSOR));
        boton_actualizar.setCursor(new Cursor(HAND_CURSOR));
        box_ano.setCursor(new Cursor(HAND_CURSOR));
        box_mes.setCursor(new Cursor(HAND_CURSOR));
        label_tareas_pendientes.setCursor(new Cursor(HAND_CURSOR));
        
        //Guarda los botones y los panales creados
        rellenaHashmaps();

        //Inserta la imagen del calendario
        try 
        {
            logica.poneImagenLabel(label_calendario, "https://proyectoseiton.000webhostapp.com//Seccion_calendario//Calendario.png");
            logica.poneImagenLabel(label_tareas_pendientes, "https://proyectoseiton.000webhostapp.com//Seccion_calendario//Tarea_compartida.png");
            logica.poneImagenLabel(label_cirulo, "https://proyectoseiton.000webhostapp.com//Seccion_calendario//Circulo.png");
            logica.poneImagenLabel(label_lupa, "https://proyectoseiton.000webhostapp.com//Seccion_calendario//Lupa.png");
            label_cirulo.setVisible(false);
            
        } catch (IOException ex) 
        {
            System.out.println("No se ha podido poner la imagen");
        }
        
        //Formato de fecha
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        String [] fecha= dtf.format(LocalDateTime.now()).split("/");
        mes_actual = Integer.parseInt(fecha[1]);
        ano_actual = Integer.parseInt(fecha[0]);
        //Setea los box de la fecha
        box_mes.setSelectedIndex(mes_actual-1);
        box_ano.setSelectedIndex(2);
        
        //Coloca el mes en el calendario
        label_mes.setText(logica.devuelveMes(mes_actual));
        //Coloca los días en los paneles correspondientes del calendario
        colocaDias(logica.primerDiaMes(mes_actual, ano_actual), logica.numeroDiasMes(mes_actual));
        //Guarda las actividades que tiene el usuario
        introduceActividades(ano_actual,mes_actual);
        //Actualiza la interfaz gráfica
        this.updateUI();
    }
    
    //Introduce las actividades dentro del calendario.
    private void introduceActividades(int ano, int mes) 
    {
        try{
            //Consulta a la base de datos el total de actividades.
            total_actividades_mes=Integer.parseInt(Conexion.consultaValor("count(id)", "Select count(id) from Actividades where Usuario='"+InicioSesion.nombreUsuario+"' AND Fecha_realizacion>='"+ano+"-"+mes+"-01' AND Fecha_realizacion<'"+ano+"-"+(mes+1)+"-01'"));
            total_act_compartidas_mes=Integer.parseInt(Conexion.consultaValor("count(id)", "Select count(id) FROM Actividades where Fecha_realizacion>='"+ano+"-"+mes+"-01' AND Fecha_realizacion<'"+ano+"-"+(mes+1)+"-01' AND Compartido_estado= 'Compartido' AND Compartido_con ='"+InicioSesion.nombreUsuario+"'"));

            //Rellena la matriz de con las actividades de la bbdd
            actividades_propias=consultaActividadesMes(ano,mes,InicioSesion.nombreUsuario);
            actividades_compartidas=consultaActividadesCompartidas(ano,mes,InicioSesion.nombreUsuario);
            
            //Guarda las tareas propias y las compartidas en un mismo array
            System.arraycopy(actividades_propias, 0, total_actividades, 0, total_actividades_mes);
            System.arraycopy(actividades_compartidas, 0, total_actividades, total_actividades_mes, total_act_compartidas_mes);
            
            //Recupera la información de todas las actividades.
            for(int i=0;i<93;i++)
            {
                //Siempre que haya una actividad la introduce en el calendario
                if(total_actividades[i][0]!=null)
                {                    
                    String panel="panel" + (Integer.parseInt(total_actividades[i][3].split("-")[2])+logica.primerDiaMes(mes, ano)-2);
                    introduceBoton(i,(JPanel) devuelvePanel(panel));
                }
            }
            //Actualiza las notificaciones de las tareas compartidas
            comprebaNotificaciones();
            
        }catch(Exception e){
            System.err.println(e);
        }
    }
    
    //Actualiza las notificaciones de las tareas compartidas
    private void comprebaNotificaciones(){
        int respuesta;
        try {
            //Consulta las actividades compartidas con el usuario activo
            respuesta = Integer.parseInt(Conexion.consultaValor("count(id)", "SELECT count(id) FROM Actividades where Compartido_estado='Esperando' and Compartido_con='"+InicioSesion.nombreUsuario+"'"));
        
            if(respuesta==0 && hayNotificacion){
            label_cirulo.setVisible(false);
            label_num_notificaciones.setText("");
            hayNotificacion=false;

            }
            else if(respuesta!=0 && !hayNotificacion){
                label_cirulo.setVisible(true);
                label_num_notificaciones.setText(String.valueOf(respuesta));
                hayNotificacion=true;
            }
            else if(respuesta!=0 && hayNotificacion){
                label_cirulo.setVisible(true);
                label_num_notificaciones.setText(String.valueOf(respuesta));
                hayNotificacion=true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(PanelCalendario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //Introduce botones en el panel.
    private void introduceBoton(int actividad,JPanel panel)
     {    
        String prioridad = total_actividades[actividad][5];
        //Crea un nombre por cada botón
        String nombre="boton"+actividad;
        JButton boton = new JButton(" "); //Crea el botón
        botones.put(nombre, boton); //Introduce el botón en el hasmap.
        panel.add(boton);   //Añade el botón al panel

        //Se le añade un escuchador a cada botón.
        boton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //Pasa el evento a la función que muestra el mensaje
                botones_actionPerformed(e);
            }
        });
        
        //Dependiendo de la prioridad el botón se rellena de un color u otro.
        switch(prioridad)
        {
            case "Baja":
                boton.setBackground(Color.cyan);
                break;
            case "Media":
                boton.setBackground(Color.orange);

                break;
            case "Alta":
                boton.setBackground(Color.red);
                break;
        }
        
        //Coloca los iconos a los botones dependiendo de la actividad
        poneIconoBotones(actividad, boton);
        
        //Le asigna un nombre al botón.
        boton.setName(nombre);
    }
    
    //Coloca un icono dependiendo si la actividad es compartida o está en espera de respuesta.
    private void poneIconoBotones(int actividad, JButton boton){
        
        try{
            String estado = total_actividades[actividad][9];
        
            if(estado.equals("Compartido")){
                boton.setText("");
                logica.poneImagenBoton(boton,"https://proyectoseiton.000webhostapp.com//Seccion_calendario//Tarea_compartida.png", "Compartido");
            }else if(estado.equals("Esperando")){
                boton.setText("");
                logica.poneImagenBoton(boton,"https://proyectoseiton.000webhostapp.com//Seccion_calendario//Reloj.png","Esperando");
            }
        }catch(Exception e){System.out.println(e);}
    }
    
    //Función que identifica el botón pulsado y muestra la actividad correspondiente
    private void botones_actionPerformed(ActionEvent e) {
        //Le da una referencia al objeto del que proviene el evento.
        Object boton=e.getSource();
	if(boton instanceof JButton){
            String nombre=((JButton) boton).getName();  //Recupera el nombre del botón
            String[] split=nombre.split("n");   //Separa el número del nombre. Ej: boton1 - boton,1
            int numero=Integer.parseInt(split[1]);  //Guarda el número para saber a qué actividad de la matriz hace referencia.
            
            panel_actividad.setVisible(true); //Hace el panel que muestra la actividad visible.
            try 
            {
                logica.poneImagenLabel(label_flecha, "https://proyectoseiton.000webhostapp.com//Seccion_calendario//Flecha.png");
            } 
            catch (IOException ex) 
            {
                 System.out.println("No se ha podido poner la imagen");
            }
            //Rellena los campos del panel de la actividad con los datos de la matriz
            rellenaActividad(numero);
	}
    }

    //Rellena los hashmap con los paneles y los labels
    private void rellenaHashmaps(){
        
        //Guarda los componentes en un HashMap para facilitar el acceso a ellos.
        for (Component panel : panel_completo.getComponents()) 
        {
            if (panel instanceof JPanel && panel.getName().contains("panel")) 
            { 
                paneles.put(panel.getName(), panel);
            }
        }
    }
    
    //Rellena el panel de la actividad.
    private void rellenaActividad(int actividad)
    {
        //Setea los campos
        caja_nombre.setText(total_actividades[actividad][1]);
        caja_fecha.setText(total_actividades[actividad][3]);
        caja_hora.setText(total_actividades[actividad][4]);
        caja_prioridad.setText(total_actividades[actividad][5]);
        caja_categoria.setText(total_actividades[actividad][6]);
        caja_compartido_por.setText(total_actividades[actividad][11]);

        //Tiene la estructura html para que respete los límites del label
        label_comentario.setText("<html> <p text-align:Left;>"+"'"+total_actividades[actividad][7]+"'"+"</p>"+"</html>"); 
        if(total_actividades[actividad][9].equals("Compartido") || total_actividades[actividad][9].equals("Esperando")){
            caja_compartido_con.setText(total_actividades[actividad][10]);
        }
        else{
            caja_compartido_con.setText("No compartido");
        } 
        
        //Si la tarea no ha sido creada por el usuario de la sesión acutal, no deja borrar la actividad
        if(!total_actividades[actividad][11].equals(InicioSesion.nombreUsuario)){
            boton_borrar.setEnabled(false);
        }else{
            boton_borrar.setEnabled(true);
        }
    }
    
    //Borra todos los botones del calendario
    private void borraBotones() 
    {
        //Elimina las actividades de la matriz.
        for(int i=0;i<=92;i++)
        {
            for(int j=0;j<=7;j++)
            {
                total_actividades[i][j]=null;
            }
        }
        
        //Elimina los botones del panel
        for (Component boton : panel_completo.getComponents()) 
        {
            if (boton instanceof JPanel) 
            { 
                ((JPanel) boton).removeAll();
            }
        }
    }
    
    //Devuelve un JPanel si existe dentro de nuestro hashmap.
    private JPanel devuelvePanel(String name) 
    {
        //Al ser un objeto de clave-valor. Busca por la clave.
        if (paneles.containsKey(name)) 
        {
            return (JPanel) paneles.get(name);
        }
        else return null;
    }
    
    //Pone nombres a los paneles.
    private void poneNombresPaneles()
    {        
        //Variable que nos indica el número del siguiente panel
        int num=0;
       
        //Busca objetos de tipo panel en el panel_completo
        for (Component panel : panel_completo.getComponents()) 
        {
            String nombre="panel"+num;
            if (panel instanceof JPanel) 
            { 
                panel.setName(nombre);
                num++;
            }
        }
    }
    
    //Introduce los días del mes en el calendario.
    private void colocaDias(int primer_dia, int num_dias_mes)
    {
        int primerDia = primer_dia;
        int diasMes = num_dias_mes;
        int x=1, contador=0;
        //Busca objetos de tipo label en el panel_completo
        for (Component label : panel_completo.getComponents()) 
        {
            if (label instanceof JLabel) 
            { 
                //Introduce los días del mes de diciembre empezando por el miércoles.
                if(contador>=(primerDia)-1&&x<=diasMes)
                {
                    ((JLabel) label).setText(String.valueOf(x));
                    x++;
                    contador++;
                }
                else if(contador<(primerDia-1)|contador>diasMes)
                {
                    ((JLabel) label).setText("");
                    contador++;
                }
            }
        }
    }
        
    //Actualiza las actividades del calendario
    private void actualizaCalendario(){
        
        try{
            //Guarda la elección del usuario
            int boxAno=Integer.parseInt(box_ano.getSelectedItem().toString());
            int boxMes=Integer.parseInt(box_mes.getSelectedItem().toString());

            //Borra los botones de las actividades
            borraBotones();
            //Coloca el mes en el calendario
            label_mes.setText(logica.devuelveMes(boxMes));
            //Coloca los dias en los paneles correspondientes de ese mes 
            colocaDias(logica.primerDiaMes(boxMes, boxAno), logica.numeroDiasMes(boxMes));
            //Introduce las actividades
            introduceActividades(boxAno,boxMes);
            //Actualiza las notificaciones
            comprebaNotificaciones();
            //Actualiza la interfaz gráfica
            this.updateUI();
        }catch(Exception e ){
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "Selecciona mes y año");
        }
    }
    
    //Devuelve el primer día del mes actual
    public static int primerDiaMesAcual()
    {
        //Formato de fecha
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        String [] fecha= dtf.format(LocalDateTime.now()).split("/");
        int mes = Integer.parseInt(fecha[1]);
        int ano = Integer.parseInt(fecha[0]);
        
        //Crea una instancia con la fecha pasada para obtener el día
        Calendar c = Calendar.getInstance();
        c.set(ano,mes-1,1); 
        int numSemana =  c.get(Calendar.DAY_OF_WEEK);
        
        //Variable que va a contener el resultado
        int diaSemana=0;
        
        switch (numSemana) {
            case Calendar.MONDAY:
                diaSemana = 1;
                break;
            case Calendar.TUESDAY:
                diaSemana = 2;
                break;
            case Calendar.WEDNESDAY:
                diaSemana = 3;
                break;
            case Calendar.THURSDAY:
                diaSemana = 4;
                break;
            case Calendar.FRIDAY:
                diaSemana = 5;
            break;
            case Calendar.SATURDAY:
                diaSemana = 6;
                break;
            case Calendar.SUNDAY:
                diaSemana = 7;
            break;
        }
        return diaSemana;
    }    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel_actividad = new javax.swing.JPanel();
        caja_nombre = new javax.swing.JTextField();
        caja_fecha = new javax.swing.JTextField();
        caja_hora = new javax.swing.JTextField();
        caja_prioridad = new javax.swing.JTextField();
        caja_categoria = new javax.swing.JTextField();
        caja_compartido_con = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        label_flecha = new javax.swing.JLabel();
        label_comentario = new javax.swing.JLabel();
        boton_borrar = new javax.swing.JButton();
        caja_compartido_por = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        panel_completo = new javax.swing.JPanel();
        panel1 = new javax.swing.JPanel();
        label_c1 = new javax.swing.JLabel();
        label1 = new javax.swing.JLabel();
        panel2 = new javax.swing.JPanel();
        label_c2 = new javax.swing.JLabel();
        label2 = new javax.swing.JLabel();
        panel3 = new javax.swing.JPanel();
        label_c3 = new javax.swing.JLabel();
        label3 = new javax.swing.JLabel();
        panel4 = new javax.swing.JPanel();
        label_c4 = new javax.swing.JLabel();
        label4 = new javax.swing.JLabel();
        panel5 = new javax.swing.JPanel();
        label_c5 = new javax.swing.JLabel();
        label5 = new javax.swing.JLabel();
        panel6 = new javax.swing.JPanel();
        label_c6 = new javax.swing.JLabel();
        label6 = new javax.swing.JLabel();
        panel7 = new javax.swing.JPanel();
        label_c7 = new javax.swing.JLabel();
        label7 = new javax.swing.JLabel();
        panel8 = new javax.swing.JPanel();
        label_c8 = new javax.swing.JLabel();
        label8 = new javax.swing.JLabel();
        panel9 = new javax.swing.JPanel();
        label_c9 = new javax.swing.JLabel();
        label9 = new javax.swing.JLabel();
        panel10 = new javax.swing.JPanel();
        label_c10 = new javax.swing.JLabel();
        label10 = new javax.swing.JLabel();
        panel11 = new javax.swing.JPanel();
        label_c11 = new javax.swing.JLabel();
        label11 = new javax.swing.JLabel();
        panel12 = new javax.swing.JPanel();
        label_c12 = new javax.swing.JLabel();
        label12 = new javax.swing.JLabel();
        panel13 = new javax.swing.JPanel();
        label_c13 = new javax.swing.JLabel();
        label13 = new javax.swing.JLabel();
        panel14 = new javax.swing.JPanel();
        label_c14 = new javax.swing.JLabel();
        label14 = new javax.swing.JLabel();
        panel15 = new javax.swing.JPanel();
        label_c15 = new javax.swing.JLabel();
        label15 = new javax.swing.JLabel();
        panel16 = new javax.swing.JPanel();
        label_c16 = new javax.swing.JLabel();
        label16 = new javax.swing.JLabel();
        panel17 = new javax.swing.JPanel();
        label_c17 = new javax.swing.JLabel();
        label17 = new javax.swing.JLabel();
        panel18 = new javax.swing.JPanel();
        label_c18 = new javax.swing.JLabel();
        label18 = new javax.swing.JLabel();
        panel19 = new javax.swing.JPanel();
        label_c19 = new javax.swing.JLabel();
        label19 = new javax.swing.JLabel();
        panel20 = new javax.swing.JPanel();
        label_c20 = new javax.swing.JLabel();
        label20 = new javax.swing.JLabel();
        panel21 = new javax.swing.JPanel();
        label_c21 = new javax.swing.JLabel();
        label21 = new javax.swing.JLabel();
        panel22 = new javax.swing.JPanel();
        label_c22 = new javax.swing.JLabel();
        label22 = new javax.swing.JLabel();
        panel23 = new javax.swing.JPanel();
        label_c23 = new javax.swing.JLabel();
        label23 = new javax.swing.JLabel();
        panel24 = new javax.swing.JPanel();
        label_c24 = new javax.swing.JLabel();
        label24 = new javax.swing.JLabel();
        panel25 = new javax.swing.JPanel();
        label_c25 = new javax.swing.JLabel();
        label25 = new javax.swing.JLabel();
        panel26 = new javax.swing.JPanel();
        label_c26 = new javax.swing.JLabel();
        label26 = new javax.swing.JLabel();
        panel27 = new javax.swing.JPanel();
        label_c27 = new javax.swing.JLabel();
        label27 = new javax.swing.JLabel();
        panel28 = new javax.swing.JPanel();
        label_c28 = new javax.swing.JLabel();
        label28 = new javax.swing.JLabel();
        panel29 = new javax.swing.JPanel();
        label_c29 = new javax.swing.JLabel();
        label29 = new javax.swing.JLabel();
        panel30 = new javax.swing.JPanel();
        label_c30 = new javax.swing.JLabel();
        label30 = new javax.swing.JLabel();
        panel31 = new javax.swing.JPanel();
        label_c31 = new javax.swing.JLabel();
        label31 = new javax.swing.JLabel();
        panel32 = new javax.swing.JPanel();
        label_c32 = new javax.swing.JLabel();
        label32 = new javax.swing.JLabel();
        panel33 = new javax.swing.JPanel();
        label_c33 = new javax.swing.JLabel();
        label33 = new javax.swing.JLabel();
        panel34 = new javax.swing.JPanel();
        label_c34 = new javax.swing.JLabel();
        label34 = new javax.swing.JLabel();
        panel35 = new javax.swing.JPanel();
        label_c35 = new javax.swing.JLabel();
        label35 = new javax.swing.JLabel();
        panel36 = new javax.swing.JPanel();
        label_c36 = new javax.swing.JLabel();
        label36 = new javax.swing.JLabel();
        panel37 = new javax.swing.JPanel();
        label_c37 = new javax.swing.JLabel();
        label37 = new javax.swing.JLabel();
        panel38 = new javax.swing.JPanel();
        label_c38 = new javax.swing.JLabel();
        label38 = new javax.swing.JLabel();
        panel39 = new javax.swing.JPanel();
        label_c39 = new javax.swing.JLabel();
        label39 = new javax.swing.JLabel();
        panel40 = new javax.swing.JPanel();
        label_c40 = new javax.swing.JLabel();
        label40 = new javax.swing.JLabel();
        panel41 = new javax.swing.JPanel();
        label_c41 = new javax.swing.JLabel();
        label41 = new javax.swing.JLabel();
        panel42 = new javax.swing.JPanel();
        label_c42 = new javax.swing.JLabel();
        label42 = new javax.swing.JLabel();
        label_domingo = new javax.swing.JLabel();
        label_lunes = new javax.swing.JLabel();
        label_martes = new javax.swing.JLabel();
        label_miercoles = new javax.swing.JLabel();
        label_jueves = new javax.swing.JLabel();
        label_viernes = new javax.swing.JLabel();
        label_sabado = new javax.swing.JLabel();
        label_calendario = new javax.swing.JLabel();
        label_mes = new javax.swing.JLabel();
        box_ano = new javax.swing.JComboBox<>();
        box_mes = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        label_lupa = new javax.swing.JLabel();
        boton_actualizar = new javax.swing.JButton();
        label_num_notificaciones = new javax.swing.JLabel();
        label_cirulo = new javax.swing.JLabel();
        label_tareas_pendientes = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setMinimumSize(new java.awt.Dimension(1275, 675));
        setPreferredSize(new java.awt.Dimension(1275, 775));
        setLayout(null);

        panel_actividad.setBackground(new java.awt.Color(255, 255, 255));
        panel_actividad.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        panel_actividad.setMaximumSize(new java.awt.Dimension(460, 500));
        panel_actividad.setMinimumSize(new java.awt.Dimension(460, 500));
        panel_actividad.setPreferredSize(new java.awt.Dimension(460, 500));
        panel_actividad.setLayout(null);
        panel_actividad.add(caja_nombre);
        caja_nombre.setBounds(225, 80, 171, 30);
        panel_actividad.add(caja_fecha);
        caja_fecha.setBounds(225, 115, 171, 30);
        panel_actividad.add(caja_hora);
        caja_hora.setBounds(225, 150, 171, 30);
        panel_actividad.add(caja_prioridad);
        caja_prioridad.setBounds(225, 185, 171, 30);
        panel_actividad.add(caja_categoria);
        caja_categoria.setBounds(225, 220, 171, 30);
        panel_actividad.add(caja_compartido_con);
        caja_compartido_con.setBounds(225, 290, 171, 30);

        jLabel4.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 65, 106));
        jLabel4.setText("Prioridad:");
        panel_actividad.add(jLabel4);
        jLabel4.setBounds(70, 185, 90, 18);

        jLabel5.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 65, 106));
        jLabel5.setText("Categoría:");
        panel_actividad.add(jLabel5);
        jLabel5.setBounds(70, 220, 153, 20);

        jLabel6.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 65, 106));
        jLabel6.setText("Hora:");
        panel_actividad.add(jLabel6);
        jLabel6.setBounds(70, 150, 153, 21);

        jLabel2.setFont(new java.awt.Font("Source Sans Pro Light", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 65, 106));
        jLabel2.setText("Actividad");
        panel_actividad.add(jLabel2);
        jLabel2.setBounds(160, 20, 146, 46);

        jLabel7.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 65, 106));
        jLabel7.setText("Fecha:");
        panel_actividad.add(jLabel7);
        jLabel7.setBounds(70, 115, 153, 20);

        jLabel8.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 65, 106));
        jLabel8.setText("Comentario:");
        panel_actividad.add(jLabel8);
        jLabel8.setBounds(70, 330, 73, 29);

        jLabel3.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 65, 106));
        jLabel3.setText("Nombre:");
        panel_actividad.add(jLabel3);
        jLabel3.setBounds(70, 80, 87, 20);

        jLabel9.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 65, 106));
        panel_actividad.add(jLabel9);
        jLabel9.setBounds(66, 216, 153, 20);

        jLabel10.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 65, 106));
        jLabel10.setText("Compartido con:");
        panel_actividad.add(jLabel10);
        jLabel10.setBounds(70, 290, 153, 20);

        label_flecha.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                label_flechaMouseClicked(evt);
            }
        });
        panel_actividad.add(label_flecha);
        label_flecha.setBounds(7, 7, 28, 27);

        label_comentario.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        label_comentario.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        label_comentario.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_actividad.add(label_comentario);
        label_comentario.setBounds(70, 360, 328, 97);

        boton_borrar.setText("Borrar actividad");
        boton_borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boton_borrarActionPerformed(evt);
            }
        });
        panel_actividad.add(boton_borrar);
        boton_borrar.setBounds(180, 470, 113, 22);
        panel_actividad.add(caja_compartido_por);
        caja_compartido_por.setBounds(225, 255, 171, 30);

        jLabel11.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 65, 106));
        jLabel11.setText("Compartido por:");
        panel_actividad.add(jLabel11);
        jLabel11.setBounds(70, 255, 153, 20);

        add(panel_actividad);
        panel_actividad.setBounds(430, 120, 460, 510);

        panel_completo.setOpaque(false);
        panel_completo.setPreferredSize(new java.awt.Dimension(1213, 590));
        panel_completo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 6, 14));

        panel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel1.setMaximumSize(new java.awt.Dimension(170, 92));
        panel1.setMinimumSize(new java.awt.Dimension(170, 92));
        panel1.setOpaque(false);
        panel1.setPreferredSize(new java.awt.Dimension(137, 80));
        panel1.setRequestFocusEnabled(false);
        panel1.setLayout(new java.awt.GridBagLayout());

        label_c1.setName("label_c1"); // NOI18N
        panel1.add(label_c1, new java.awt.GridBagConstraints());

        panel_completo.add(panel1);

        label1.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label1.setText("00");
        label1.setToolTipText("");
        label1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label1.setMaximumSize(new java.awt.Dimension(16, 95));
        label1.setMinimumSize(new java.awt.Dimension(16, 95));
        label1.setName(""); // NOI18N
        label1.setPreferredSize(new java.awt.Dimension(16, 70));
        label1.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label1);
        label1.getAccessibleContext().setAccessibleParent(this);

        panel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel2.setMinimumSize(new java.awt.Dimension(172, 95));
        panel2.setOpaque(false);
        panel2.setPreferredSize(new java.awt.Dimension(137, 80));
        panel2.setRequestFocusEnabled(false);
        panel2.setLayout(new java.awt.GridBagLayout());

        label_c2.setName("label_c2"); // NOI18N
        panel2.add(label_c2, new java.awt.GridBagConstraints());

        panel_completo.add(panel2);

        label2.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label2.setText("00");
        label2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label2.setMaximumSize(new java.awt.Dimension(16, 95));
        label2.setMinimumSize(new java.awt.Dimension(16, 95));
        label2.setPreferredSize(new java.awt.Dimension(16, 70));
        label2.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label2);

        panel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel3.setMinimumSize(new java.awt.Dimension(172, 95));
        panel3.setOpaque(false);
        panel3.setPreferredSize(new java.awt.Dimension(137, 80));
        panel3.setRequestFocusEnabled(false);
        panel3.setLayout(new java.awt.GridBagLayout());

        label_c3.setName("label_c3"); // NOI18N
        panel3.add(label_c3, new java.awt.GridBagConstraints());

        panel_completo.add(panel3);

        label3.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label3.setText("00");
        label3.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label3.setMaximumSize(new java.awt.Dimension(16, 95));
        label3.setMinimumSize(new java.awt.Dimension(16, 95));
        label3.setPreferredSize(new java.awt.Dimension(16, 70));
        label3.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label3);

        panel4.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel4.setMinimumSize(new java.awt.Dimension(172, 95));
        panel4.setOpaque(false);
        panel4.setPreferredSize(new java.awt.Dimension(137, 80));
        panel4.setRequestFocusEnabled(false);
        panel4.setLayout(new java.awt.GridBagLayout());

        label_c4.setName("label_c4"); // NOI18N
        panel4.add(label_c4, new java.awt.GridBagConstraints());

        panel_completo.add(panel4);

        label4.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label4.setText("00");
        label4.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label4.setMaximumSize(new java.awt.Dimension(16, 95));
        label4.setMinimumSize(new java.awt.Dimension(16, 95));
        label4.setPreferredSize(new java.awt.Dimension(16, 70));
        label4.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label4);

        panel5.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel5.setMinimumSize(new java.awt.Dimension(172, 95));
        panel5.setOpaque(false);
        panel5.setPreferredSize(new java.awt.Dimension(137, 80));
        panel5.setRequestFocusEnabled(false);
        panel5.setLayout(new java.awt.GridBagLayout());

        label_c5.setName("label_c5"); // NOI18N
        panel5.add(label_c5, new java.awt.GridBagConstraints());

        panel_completo.add(panel5);

        label5.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label5.setText("00");
        label5.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label5.setMaximumSize(new java.awt.Dimension(16, 95));
        label5.setMinimumSize(new java.awt.Dimension(16, 95));
        label5.setPreferredSize(new java.awt.Dimension(16, 70));
        label5.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label5);

        panel6.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel6.setMinimumSize(new java.awt.Dimension(172, 95));
        panel6.setOpaque(false);
        panel6.setPreferredSize(new java.awt.Dimension(137, 80));
        panel6.setRequestFocusEnabled(false);
        panel6.setLayout(new java.awt.GridBagLayout());

        label_c6.setName("label_c6"); // NOI18N
        panel6.add(label_c6, new java.awt.GridBagConstraints());

        panel_completo.add(panel6);

        label6.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label6.setText("00");
        label6.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label6.setMaximumSize(new java.awt.Dimension(16, 95));
        label6.setMinimumSize(new java.awt.Dimension(16, 95));
        label6.setPreferredSize(new java.awt.Dimension(16, 70));
        label6.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label6);

        panel7.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel7.setMinimumSize(new java.awt.Dimension(172, 95));
        panel7.setOpaque(false);
        panel7.setPreferredSize(new java.awt.Dimension(137, 80));
        panel7.setRequestFocusEnabled(false);
        panel7.setLayout(new java.awt.GridBagLayout());

        label_c7.setName("label_c7"); // NOI18N
        panel7.add(label_c7, new java.awt.GridBagConstraints());

        panel_completo.add(panel7);

        label7.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label7.setText("00");
        label7.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label7.setMaximumSize(new java.awt.Dimension(16, 95));
        label7.setMinimumSize(new java.awt.Dimension(16, 95));
        label7.setPreferredSize(new java.awt.Dimension(16, 70));
        label7.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label7);

        panel8.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel8.setMinimumSize(new java.awt.Dimension(172, 95));
        panel8.setOpaque(false);
        panel8.setPreferredSize(new java.awt.Dimension(137, 80));
        panel8.setRequestFocusEnabled(false);
        panel8.setLayout(new java.awt.GridBagLayout());

        label_c8.setName("label_c8"); // NOI18N
        panel8.add(label_c8, new java.awt.GridBagConstraints());

        panel_completo.add(panel8);

        label8.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label8.setText("00");
        label8.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label8.setMaximumSize(new java.awt.Dimension(16, 95));
        label8.setMinimumSize(new java.awt.Dimension(16, 95));
        label8.setPreferredSize(new java.awt.Dimension(16, 70));
        label8.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label8);

        panel9.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel9.setMinimumSize(new java.awt.Dimension(172, 95));
        panel9.setOpaque(false);
        panel9.setPreferredSize(new java.awt.Dimension(137, 80));
        panel9.setRequestFocusEnabled(false);
        panel9.setLayout(new java.awt.GridBagLayout());

        label_c9.setName("label_c9"); // NOI18N
        panel9.add(label_c9, new java.awt.GridBagConstraints());

        panel_completo.add(panel9);

        label9.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label9.setText("00");
        label9.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label9.setMaximumSize(new java.awt.Dimension(16, 95));
        label9.setMinimumSize(new java.awt.Dimension(16, 95));
        label9.setPreferredSize(new java.awt.Dimension(16, 70));
        label9.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label9);

        panel10.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel10.setMinimumSize(new java.awt.Dimension(172, 95));
        panel10.setOpaque(false);
        panel10.setPreferredSize(new java.awt.Dimension(137, 80));
        panel10.setRequestFocusEnabled(false);
        panel10.setLayout(new java.awt.GridBagLayout());

        label_c10.setName("label_c10"); // NOI18N
        panel10.add(label_c10, new java.awt.GridBagConstraints());

        panel_completo.add(panel10);

        label10.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label10.setText("00");
        label10.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label10.setMaximumSize(new java.awt.Dimension(16, 95));
        label10.setMinimumSize(new java.awt.Dimension(16, 95));
        label10.setPreferredSize(new java.awt.Dimension(16, 70));
        label10.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label10);

        panel11.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel11.setMinimumSize(new java.awt.Dimension(172, 95));
        panel11.setOpaque(false);
        panel11.setPreferredSize(new java.awt.Dimension(137, 80));
        panel11.setRequestFocusEnabled(false);
        panel11.setLayout(new java.awt.GridBagLayout());

        label_c11.setName("label_c11"); // NOI18N
        panel11.add(label_c11, new java.awt.GridBagConstraints());

        panel_completo.add(panel11);

        label11.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label11.setText("00");
        label11.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label11.setMaximumSize(new java.awt.Dimension(16, 95));
        label11.setMinimumSize(new java.awt.Dimension(16, 95));
        label11.setPreferredSize(new java.awt.Dimension(16, 70));
        label11.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label11);

        panel12.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel12.setMinimumSize(new java.awt.Dimension(172, 95));
        panel12.setOpaque(false);
        panel12.setPreferredSize(new java.awt.Dimension(137, 80));
        panel12.setRequestFocusEnabled(false);
        panel12.setLayout(new java.awt.GridBagLayout());

        label_c12.setName("label_c12"); // NOI18N
        panel12.add(label_c12, new java.awt.GridBagConstraints());

        panel_completo.add(panel12);

        label12.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label12.setText("00");
        label12.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label12.setMaximumSize(new java.awt.Dimension(16, 95));
        label12.setMinimumSize(new java.awt.Dimension(16, 95));
        label12.setPreferredSize(new java.awt.Dimension(16, 70));
        label12.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label12);

        panel13.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel13.setMinimumSize(new java.awt.Dimension(172, 95));
        panel13.setOpaque(false);
        panel13.setPreferredSize(new java.awt.Dimension(137, 80));
        panel13.setRequestFocusEnabled(false);
        panel13.setLayout(new java.awt.GridBagLayout());

        label_c13.setName("label_c13"); // NOI18N
        panel13.add(label_c13, new java.awt.GridBagConstraints());

        panel_completo.add(panel13);

        label13.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label13.setText("00");
        label13.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label13.setMaximumSize(new java.awt.Dimension(16, 95));
        label13.setMinimumSize(new java.awt.Dimension(16, 95));
        label13.setPreferredSize(new java.awt.Dimension(16, 70));
        label13.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label13);

        panel14.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel14.setMinimumSize(new java.awt.Dimension(172, 95));
        panel14.setOpaque(false);
        panel14.setPreferredSize(new java.awt.Dimension(137, 80));
        panel14.setRequestFocusEnabled(false);
        panel14.setLayout(new java.awt.GridBagLayout());

        label_c14.setName("label_c14"); // NOI18N
        panel14.add(label_c14, new java.awt.GridBagConstraints());

        panel_completo.add(panel14);

        label14.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label14.setText("00");
        label14.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label14.setMaximumSize(new java.awt.Dimension(16, 95));
        label14.setMinimumSize(new java.awt.Dimension(16, 95));
        label14.setPreferredSize(new java.awt.Dimension(16, 70));
        label14.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label14);

        panel15.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel15.setMinimumSize(new java.awt.Dimension(172, 95));
        panel15.setOpaque(false);
        panel15.setPreferredSize(new java.awt.Dimension(137, 80));
        panel15.setRequestFocusEnabled(false);
        panel15.setLayout(new java.awt.GridBagLayout());

        label_c15.setName("label_c15"); // NOI18N
        panel15.add(label_c15, new java.awt.GridBagConstraints());

        panel_completo.add(panel15);

        label15.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label15.setText("00");
        label15.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label15.setMaximumSize(new java.awt.Dimension(16, 95));
        label15.setMinimumSize(new java.awt.Dimension(16, 95));
        label15.setPreferredSize(new java.awt.Dimension(16, 70));
        label15.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label15);

        panel16.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel16.setMinimumSize(new java.awt.Dimension(172, 95));
        panel16.setOpaque(false);
        panel16.setPreferredSize(new java.awt.Dimension(137, 80));
        panel16.setRequestFocusEnabled(false);
        panel16.setLayout(new java.awt.GridBagLayout());

        label_c16.setName("label_c16"); // NOI18N
        panel16.add(label_c16, new java.awt.GridBagConstraints());

        panel_completo.add(panel16);

        label16.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label16.setText("00");
        label16.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label16.setMaximumSize(new java.awt.Dimension(16, 95));
        label16.setMinimumSize(new java.awt.Dimension(16, 95));
        label16.setPreferredSize(new java.awt.Dimension(16, 70));
        label16.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label16);

        panel17.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel17.setMinimumSize(new java.awt.Dimension(172, 95));
        panel17.setOpaque(false);
        panel17.setPreferredSize(new java.awt.Dimension(137, 80));
        panel17.setRequestFocusEnabled(false);
        panel17.setLayout(new java.awt.GridBagLayout());

        label_c17.setName("label_c17"); // NOI18N
        panel17.add(label_c17, new java.awt.GridBagConstraints());

        panel_completo.add(panel17);

        label17.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label17.setText("00");
        label17.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label17.setMaximumSize(new java.awt.Dimension(16, 95));
        label17.setMinimumSize(new java.awt.Dimension(16, 95));
        label17.setPreferredSize(new java.awt.Dimension(16, 70));
        label17.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label17);

        panel18.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel18.setMinimumSize(new java.awt.Dimension(172, 95));
        panel18.setOpaque(false);
        panel18.setPreferredSize(new java.awt.Dimension(137, 80));
        panel18.setRequestFocusEnabled(false);
        panel18.setLayout(new java.awt.GridBagLayout());

        label_c18.setName("label_c18"); // NOI18N
        panel18.add(label_c18, new java.awt.GridBagConstraints());

        panel_completo.add(panel18);

        label18.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label18.setText("00");
        label18.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label18.setMaximumSize(new java.awt.Dimension(16, 95));
        label18.setMinimumSize(new java.awt.Dimension(16, 95));
        label18.setPreferredSize(new java.awt.Dimension(16, 70));
        label18.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label18);

        panel19.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel19.setMinimumSize(new java.awt.Dimension(172, 95));
        panel19.setOpaque(false);
        panel19.setPreferredSize(new java.awt.Dimension(137, 80));
        panel19.setRequestFocusEnabled(false);
        panel19.setLayout(new java.awt.GridBagLayout());

        label_c19.setName("label_c19"); // NOI18N
        panel19.add(label_c19, new java.awt.GridBagConstraints());

        panel_completo.add(panel19);

        label19.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label19.setText("00");
        label19.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label19.setMaximumSize(new java.awt.Dimension(16, 95));
        label19.setMinimumSize(new java.awt.Dimension(16, 95));
        label19.setPreferredSize(new java.awt.Dimension(16, 70));
        label19.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label19);

        panel20.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel20.setMinimumSize(new java.awt.Dimension(172, 95));
        panel20.setOpaque(false);
        panel20.setPreferredSize(new java.awt.Dimension(137, 80));
        panel20.setRequestFocusEnabled(false);
        panel20.setLayout(new java.awt.GridBagLayout());

        label_c20.setName("label_c20"); // NOI18N
        panel20.add(label_c20, new java.awt.GridBagConstraints());

        panel_completo.add(panel20);

        label20.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label20.setText("00");
        label20.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label20.setMaximumSize(new java.awt.Dimension(16, 95));
        label20.setMinimumSize(new java.awt.Dimension(16, 95));
        label20.setPreferredSize(new java.awt.Dimension(16, 70));
        label20.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label20);

        panel21.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel21.setMinimumSize(new java.awt.Dimension(172, 95));
        panel21.setOpaque(false);
        panel21.setPreferredSize(new java.awt.Dimension(137, 80));
        panel21.setRequestFocusEnabled(false);
        panel21.setLayout(new java.awt.GridBagLayout());

        label_c21.setName("label_c21"); // NOI18N
        panel21.add(label_c21, new java.awt.GridBagConstraints());

        panel_completo.add(panel21);

        label21.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label21.setText("00");
        label21.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label21.setMaximumSize(new java.awt.Dimension(16, 95));
        label21.setMinimumSize(new java.awt.Dimension(16, 95));
        label21.setPreferredSize(new java.awt.Dimension(16, 70));
        label21.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label21);

        panel22.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel22.setMinimumSize(new java.awt.Dimension(172, 95));
        panel22.setOpaque(false);
        panel22.setPreferredSize(new java.awt.Dimension(137, 80));
        panel22.setRequestFocusEnabled(false);
        panel22.setLayout(new java.awt.GridBagLayout());

        label_c22.setName("label_c22"); // NOI18N
        panel22.add(label_c22, new java.awt.GridBagConstraints());

        panel_completo.add(panel22);

        label22.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label22.setText("00");
        label22.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label22.setMaximumSize(new java.awt.Dimension(16, 95));
        label22.setMinimumSize(new java.awt.Dimension(16, 95));
        label22.setPreferredSize(new java.awt.Dimension(16, 70));
        label22.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label22);

        panel23.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel23.setMinimumSize(new java.awt.Dimension(172, 95));
        panel23.setOpaque(false);
        panel23.setPreferredSize(new java.awt.Dimension(137, 80));
        panel23.setRequestFocusEnabled(false);
        panel23.setLayout(new java.awt.GridBagLayout());

        label_c23.setName("label_c23"); // NOI18N
        panel23.add(label_c23, new java.awt.GridBagConstraints());

        panel_completo.add(panel23);

        label23.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label23.setText("00");
        label23.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label23.setMaximumSize(new java.awt.Dimension(16, 95));
        label23.setMinimumSize(new java.awt.Dimension(16, 95));
        label23.setPreferredSize(new java.awt.Dimension(16, 70));
        label23.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label23);

        panel24.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel24.setMinimumSize(new java.awt.Dimension(172, 95));
        panel24.setOpaque(false);
        panel24.setPreferredSize(new java.awt.Dimension(137, 80));
        panel24.setRequestFocusEnabled(false);
        panel24.setLayout(new java.awt.GridBagLayout());

        label_c24.setName("label_c24"); // NOI18N
        panel24.add(label_c24, new java.awt.GridBagConstraints());

        panel_completo.add(panel24);

        label24.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label24.setText("00");
        label24.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label24.setMaximumSize(new java.awt.Dimension(16, 95));
        label24.setMinimumSize(new java.awt.Dimension(16, 95));
        label24.setPreferredSize(new java.awt.Dimension(16, 70));
        label24.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label24);

        panel25.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel25.setMinimumSize(new java.awt.Dimension(172, 95));
        panel25.setOpaque(false);
        panel25.setPreferredSize(new java.awt.Dimension(137, 80));
        panel25.setRequestFocusEnabled(false);
        panel25.setLayout(new java.awt.GridBagLayout());

        label_c25.setName("label_c25"); // NOI18N
        panel25.add(label_c25, new java.awt.GridBagConstraints());

        panel_completo.add(panel25);

        label25.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label25.setText("00");
        label25.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label25.setMaximumSize(new java.awt.Dimension(16, 95));
        label25.setMinimumSize(new java.awt.Dimension(16, 95));
        label25.setPreferredSize(new java.awt.Dimension(16, 70));
        label25.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label25);

        panel26.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel26.setMinimumSize(new java.awt.Dimension(172, 95));
        panel26.setOpaque(false);
        panel26.setPreferredSize(new java.awt.Dimension(137, 80));
        panel26.setRequestFocusEnabled(false);
        panel26.setLayout(new java.awt.GridBagLayout());

        label_c26.setName("label_c26"); // NOI18N
        panel26.add(label_c26, new java.awt.GridBagConstraints());

        panel_completo.add(panel26);

        label26.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label26.setText("00");
        label26.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label26.setMaximumSize(new java.awt.Dimension(16, 95));
        label26.setMinimumSize(new java.awt.Dimension(16, 95));
        label26.setPreferredSize(new java.awt.Dimension(16, 70));
        label26.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label26);

        panel27.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel27.setMinimumSize(new java.awt.Dimension(172, 95));
        panel27.setOpaque(false);
        panel27.setPreferredSize(new java.awt.Dimension(137, 80));
        panel27.setRequestFocusEnabled(false);
        panel27.setLayout(new java.awt.GridBagLayout());

        label_c27.setName("label_c27"); // NOI18N
        panel27.add(label_c27, new java.awt.GridBagConstraints());

        panel_completo.add(panel27);

        label27.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label27.setText("00");
        label27.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label27.setMaximumSize(new java.awt.Dimension(16, 95));
        label27.setMinimumSize(new java.awt.Dimension(16, 95));
        label27.setPreferredSize(new java.awt.Dimension(16, 70));
        label27.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label27);

        panel28.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel28.setMinimumSize(new java.awt.Dimension(172, 95));
        panel28.setOpaque(false);
        panel28.setPreferredSize(new java.awt.Dimension(137, 80));
        panel28.setRequestFocusEnabled(false);
        panel28.setLayout(new java.awt.GridBagLayout());

        label_c28.setName("label_c28"); // NOI18N
        panel28.add(label_c28, new java.awt.GridBagConstraints());

        panel_completo.add(panel28);

        label28.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label28.setText("00");
        label28.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label28.setMaximumSize(new java.awt.Dimension(16, 95));
        label28.setMinimumSize(new java.awt.Dimension(16, 95));
        label28.setPreferredSize(new java.awt.Dimension(16, 70));
        label28.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label28);

        panel29.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel29.setMinimumSize(new java.awt.Dimension(172, 95));
        panel29.setOpaque(false);
        panel29.setPreferredSize(new java.awt.Dimension(137, 80));
        panel29.setRequestFocusEnabled(false);
        panel29.setLayout(new java.awt.GridBagLayout());

        label_c29.setName("label_c29"); // NOI18N
        panel29.add(label_c29, new java.awt.GridBagConstraints());

        panel_completo.add(panel29);

        label29.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label29.setText("00");
        label29.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label29.setMaximumSize(new java.awt.Dimension(16, 95));
        label29.setMinimumSize(new java.awt.Dimension(16, 95));
        label29.setPreferredSize(new java.awt.Dimension(16, 70));
        label29.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label29);

        panel30.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel30.setMinimumSize(new java.awt.Dimension(172, 95));
        panel30.setOpaque(false);
        panel30.setPreferredSize(new java.awt.Dimension(137, 80));
        panel30.setRequestFocusEnabled(false);
        panel30.setLayout(new java.awt.GridBagLayout());

        label_c30.setName("label_c30"); // NOI18N
        panel30.add(label_c30, new java.awt.GridBagConstraints());

        panel_completo.add(panel30);

        label30.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label30.setText("00");
        label30.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label30.setMaximumSize(new java.awt.Dimension(16, 95));
        label30.setMinimumSize(new java.awt.Dimension(16, 95));
        label30.setPreferredSize(new java.awt.Dimension(16, 70));
        label30.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label30);

        panel31.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel31.setMinimumSize(new java.awt.Dimension(172, 95));
        panel31.setOpaque(false);
        panel31.setPreferredSize(new java.awt.Dimension(137, 80));
        panel31.setRequestFocusEnabled(false);
        panel31.setLayout(new java.awt.GridBagLayout());

        label_c31.setName("label_c31"); // NOI18N
        panel31.add(label_c31, new java.awt.GridBagConstraints());

        panel_completo.add(panel31);

        label31.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label31.setText("00");
        label31.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label31.setMaximumSize(new java.awt.Dimension(16, 95));
        label31.setMinimumSize(new java.awt.Dimension(16, 95));
        label31.setPreferredSize(new java.awt.Dimension(16, 70));
        label31.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label31);

        panel32.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel32.setMinimumSize(new java.awt.Dimension(172, 95));
        panel32.setOpaque(false);
        panel32.setPreferredSize(new java.awt.Dimension(137, 80));
        panel32.setRequestFocusEnabled(false);
        panel32.setLayout(new java.awt.GridBagLayout());

        label_c32.setName("label_c32"); // NOI18N
        panel32.add(label_c32, new java.awt.GridBagConstraints());

        panel_completo.add(panel32);

        label32.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label32.setText("00");
        label32.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label32.setMaximumSize(new java.awt.Dimension(16, 95));
        label32.setMinimumSize(new java.awt.Dimension(16, 95));
        label32.setPreferredSize(new java.awt.Dimension(16, 70));
        label32.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label32);

        panel33.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel33.setMinimumSize(new java.awt.Dimension(172, 95));
        panel33.setOpaque(false);
        panel33.setPreferredSize(new java.awt.Dimension(137, 80));
        panel33.setRequestFocusEnabled(false);
        panel33.setLayout(new java.awt.GridBagLayout());

        label_c33.setName("label_c33"); // NOI18N
        panel33.add(label_c33, new java.awt.GridBagConstraints());

        panel_completo.add(panel33);

        label33.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label33.setText("00");
        label33.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label33.setMaximumSize(new java.awt.Dimension(16, 95));
        label33.setMinimumSize(new java.awt.Dimension(16, 95));
        label33.setPreferredSize(new java.awt.Dimension(16, 70));
        label33.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label33);

        panel34.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel34.setMinimumSize(new java.awt.Dimension(172, 95));
        panel34.setOpaque(false);
        panel34.setPreferredSize(new java.awt.Dimension(137, 80));
        panel34.setRequestFocusEnabled(false);
        panel34.setLayout(new java.awt.GridBagLayout());

        label_c34.setName("label_c34"); // NOI18N
        panel34.add(label_c34, new java.awt.GridBagConstraints());

        panel_completo.add(panel34);

        label34.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label34.setText("00");
        label34.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label34.setMaximumSize(new java.awt.Dimension(16, 95));
        label34.setMinimumSize(new java.awt.Dimension(16, 95));
        label34.setPreferredSize(new java.awt.Dimension(16, 70));
        label34.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label34);

        panel35.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel35.setMinimumSize(new java.awt.Dimension(172, 95));
        panel35.setOpaque(false);
        panel35.setPreferredSize(new java.awt.Dimension(137, 80));
        panel35.setRequestFocusEnabled(false);
        panel35.setLayout(new java.awt.GridBagLayout());

        label_c35.setName("label_c35"); // NOI18N
        panel35.add(label_c35, new java.awt.GridBagConstraints());

        panel_completo.add(panel35);

        label35.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label35.setText("00");
        label35.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label35.setMaximumSize(new java.awt.Dimension(16, 95));
        label35.setMinimumSize(new java.awt.Dimension(16, 95));
        label35.setPreferredSize(new java.awt.Dimension(16, 70));
        label35.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label35);

        panel36.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel36.setMinimumSize(new java.awt.Dimension(172, 95));
        panel36.setOpaque(false);
        panel36.setPreferredSize(new java.awt.Dimension(137, 80));
        panel36.setRequestFocusEnabled(false);
        panel36.setLayout(new java.awt.GridBagLayout());

        label_c36.setName("label_c36"); // NOI18N
        panel36.add(label_c36, new java.awt.GridBagConstraints());

        panel_completo.add(panel36);

        label36.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label36.setText("00");
        label36.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label36.setMaximumSize(new java.awt.Dimension(16, 95));
        label36.setMinimumSize(new java.awt.Dimension(16, 95));
        label36.setPreferredSize(new java.awt.Dimension(16, 70));
        label36.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label36);

        panel37.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel37.setMinimumSize(new java.awt.Dimension(172, 95));
        panel37.setOpaque(false);
        panel37.setPreferredSize(new java.awt.Dimension(137, 80));
        panel37.setRequestFocusEnabled(false);
        panel37.setLayout(new java.awt.GridBagLayout());

        label_c37.setName("label_c37"); // NOI18N
        panel37.add(label_c37, new java.awt.GridBagConstraints());

        panel_completo.add(panel37);

        label37.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label37.setText("00");
        label37.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label37.setMaximumSize(new java.awt.Dimension(16, 95));
        label37.setMinimumSize(new java.awt.Dimension(16, 95));
        label37.setPreferredSize(new java.awt.Dimension(16, 70));
        label37.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label37);

        panel38.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel38.setMinimumSize(new java.awt.Dimension(172, 95));
        panel38.setOpaque(false);
        panel38.setPreferredSize(new java.awt.Dimension(137, 80));
        panel38.setRequestFocusEnabled(false);
        panel38.setLayout(new java.awt.GridBagLayout());

        label_c38.setName("label_c38"); // NOI18N
        panel38.add(label_c38, new java.awt.GridBagConstraints());

        panel_completo.add(panel38);

        label38.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label38.setText("00");
        label38.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label38.setMaximumSize(new java.awt.Dimension(16, 95));
        label38.setMinimumSize(new java.awt.Dimension(16, 95));
        label38.setPreferredSize(new java.awt.Dimension(16, 70));
        label38.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label38);

        panel39.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel39.setMinimumSize(new java.awt.Dimension(172, 95));
        panel39.setOpaque(false);
        panel39.setPreferredSize(new java.awt.Dimension(137, 80));
        panel39.setRequestFocusEnabled(false);
        panel39.setLayout(new java.awt.GridBagLayout());

        label_c39.setName("label_c39"); // NOI18N
        panel39.add(label_c39, new java.awt.GridBagConstraints());

        panel_completo.add(panel39);

        label39.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label39.setText("00");
        label39.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label39.setMaximumSize(new java.awt.Dimension(16, 95));
        label39.setMinimumSize(new java.awt.Dimension(16, 95));
        label39.setPreferredSize(new java.awt.Dimension(16, 70));
        label39.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label39);

        panel40.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel40.setMinimumSize(new java.awt.Dimension(172, 95));
        panel40.setOpaque(false);
        panel40.setPreferredSize(new java.awt.Dimension(137, 80));
        panel40.setRequestFocusEnabled(false);
        panel40.setLayout(new java.awt.GridBagLayout());

        label_c40.setName("label_c40"); // NOI18N
        panel40.add(label_c40, new java.awt.GridBagConstraints());

        panel_completo.add(panel40);

        label40.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label40.setText("00");
        label40.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label40.setMaximumSize(new java.awt.Dimension(16, 95));
        label40.setMinimumSize(new java.awt.Dimension(16, 95));
        label40.setPreferredSize(new java.awt.Dimension(16, 70));
        label40.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label40);

        panel41.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel41.setMinimumSize(new java.awt.Dimension(172, 95));
        panel41.setOpaque(false);
        panel41.setPreferredSize(new java.awt.Dimension(137, 80));
        panel41.setRequestFocusEnabled(false);
        panel41.setLayout(new java.awt.GridBagLayout());

        label_c41.setName("label_c41"); // NOI18N
        panel41.add(label_c41, new java.awt.GridBagConstraints());

        panel_completo.add(panel41);

        label41.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label41.setText("00");
        label41.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label41.setMaximumSize(new java.awt.Dimension(16, 95));
        label41.setMinimumSize(new java.awt.Dimension(16, 95));
        label41.setPreferredSize(new java.awt.Dimension(16, 70));
        label41.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label41);

        panel42.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel42.setMinimumSize(new java.awt.Dimension(172, 95));
        panel42.setOpaque(false);
        panel42.setPreferredSize(new java.awt.Dimension(137, 80));
        panel42.setRequestFocusEnabled(false);
        panel42.setLayout(new java.awt.GridBagLayout());

        label_c42.setName("label_c42"); // NOI18N
        panel42.add(label_c42, new java.awt.GridBagConstraints());

        panel_completo.add(panel42);

        label42.setFont(new java.awt.Font("Source Sans Pro Light", 1, 14)); // NOI18N
        label42.setText("00");
        label42.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        label42.setMaximumSize(new java.awt.Dimension(16, 95));
        label42.setMinimumSize(new java.awt.Dimension(16, 95));
        label42.setPreferredSize(new java.awt.Dimension(16, 70));
        label42.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        panel_completo.add(label42);

        add(panel_completo);
        panel_completo.setBounds(80, 90, 1163, 580);

        label_domingo.setFont(new java.awt.Font("Source Sans Pro Light", 1, 18)); // NOI18N
        label_domingo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_domingo.setText("Domingo");
        add(label_domingo);
        label_domingo.setBounds(1080, 70, 150, 30);

        label_lunes.setFont(new java.awt.Font("Source Sans Pro Light", 1, 18)); // NOI18N
        label_lunes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_lunes.setText("Lunes");
        add(label_lunes);
        label_lunes.setBounds(90, 70, 150, 30);

        label_martes.setFont(new java.awt.Font("Source Sans Pro Light", 1, 18)); // NOI18N
        label_martes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_martes.setText("Martes");
        add(label_martes);
        label_martes.setBounds(250, 70, 150, 30);

        label_miercoles.setFont(new java.awt.Font("Source Sans Pro Light", 1, 18)); // NOI18N
        label_miercoles.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_miercoles.setText("Miércoles");
        add(label_miercoles);
        label_miercoles.setBounds(420, 70, 150, 30);

        label_jueves.setFont(new java.awt.Font("Source Sans Pro Light", 1, 18)); // NOI18N
        label_jueves.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_jueves.setText("Jueves");
        add(label_jueves);
        label_jueves.setBounds(580, 70, 160, 30);

        label_viernes.setFont(new java.awt.Font("Source Sans Pro Light", 1, 18)); // NOI18N
        label_viernes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_viernes.setText("Viernes");
        add(label_viernes);
        label_viernes.setBounds(750, 70, 150, 30);

        label_sabado.setFont(new java.awt.Font("Source Sans Pro Light", 1, 18)); // NOI18N
        label_sabado.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_sabado.setText("Sábado");
        add(label_sabado);
        label_sabado.setBounds(920, 70, 140, 30);
        add(label_calendario);
        label_calendario.setBounds(80, 70, 1160, 600);

        label_mes.setFont(new java.awt.Font("Source Sans Pro Light", 1, 24)); // NOI18N
        label_mes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_mes.setText("DICIEMBRE");
        label_mes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        add(label_mes);
        label_mes.setBounds(80, 0, 1160, 40);

        box_ano.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2020", "2021", "2022", "2023", "2024", "2025", "2026" }));
        box_ano.setSelectedIndex(-1);
        add(box_ano);
        box_ano.setBounds(1140, 710, 72, 22);

        box_mes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        box_mes.setSelectedIndex(-1);
        add(box_mes);
        box_mes.setBounds(1080, 710, 50, 22);

        jLabel1.setText("Cambiar de mes:");
        add(jLabel1);
        jLabel1.setBounds(1080, 690, 110, 16);

        label_lupa.setPreferredSize(new java.awt.Dimension(50, 50));
        label_lupa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                label_lupaMouseClicked(evt);
            }
        });
        add(label_lupa);
        label_lupa.setBounds(1220, 707, 25, 25);

        boton_actualizar.setText("Actualizar");
        boton_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boton_actualizarActionPerformed(evt);
            }
        });
        add(boton_actualizar);
        boton_actualizar.setBounds(590, 710, 130, 22);

        label_num_notificaciones.setFont(new java.awt.Font("Source Sans Pro Light", 1, 12)); // NOI18N
        label_num_notificaciones.setForeground(new java.awt.Color(255, 255, 255));
        label_num_notificaciones.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(label_num_notificaciones);
        label_num_notificaciones.setBounds(105, 685, 20, 20);
        add(label_cirulo);
        label_cirulo.setBounds(105, 685, 20, 20);

        label_tareas_pendientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                label_tareas_pendientesMouseClicked(evt);
            }
        });
        add(label_tareas_pendientes);
        label_tareas_pendientes.setBounds(80, 690, 40, 40);
    }// </editor-fold>//GEN-END:initComponents

    //Oculta el panel de la actividad
    private void label_flechaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_label_flechaMouseClicked
        panel_actividad.setVisible(false);
    }//GEN-LAST:event_label_flechaMouseClicked

    private void label_lupaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_label_lupaMouseClicked
        actualizaCalendario();
    }//GEN-LAST:event_label_lupaMouseClicked

    private void boton_borrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boton_borrarActionPerformed
        //Ventana emergente para asegurarse que el usuario quiere borrar la actividad.
        int respuesta = JOptionPane.showConfirmDialog(null, "¿Esta seguro?", "Alerta!", JOptionPane.YES_NO_OPTION);
        
        if(respuesta == 0){
            try {
                Conexion.update_delete("delete from Actividades where Usuario='"+InicioSesion.nombreUsuario+"' AND Nombre='"+caja_nombre.getText()+"'");
                //Oculta el panel de la actividad.
                panel_actividad.setVisible(false);
                actualizaCalendario();
            } catch (SQLException ex) {
                Logger.getLogger(PanelCalendario.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_boton_borrarActionPerformed

    //Actualiza las actividades del calendario
    private void boton_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boton_actualizarActionPerformed
        actualizaCalendario();
    }//GEN-LAST:event_boton_actualizarActionPerformed

    
    private void label_tareas_pendientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_label_tareas_pendientesMouseClicked
        
        if(!this.tp_Frame.isVisible()){
            this.tp_Frame=new TareasPendientes();
            this.tp_Frame.setVisible(true);
        }else{
            this.tp_Frame.setVisible(false);
        }
    }//GEN-LAST:event_label_tareas_pendientesMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton boton_actualizar;
    private javax.swing.JButton boton_borrar;
    private javax.swing.JComboBox<String> box_ano;
    private javax.swing.JComboBox<String> box_mes;
    private javax.swing.JTextField caja_categoria;
    private javax.swing.JTextField caja_compartido_con;
    private javax.swing.JTextField caja_compartido_por;
    private javax.swing.JTextField caja_fecha;
    private javax.swing.JTextField caja_hora;
    private javax.swing.JTextField caja_nombre;
    private javax.swing.JTextField caja_prioridad;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel label1;
    private javax.swing.JLabel label10;
    private javax.swing.JLabel label11;
    private javax.swing.JLabel label12;
    private javax.swing.JLabel label13;
    private javax.swing.JLabel label14;
    private javax.swing.JLabel label15;
    private javax.swing.JLabel label16;
    private javax.swing.JLabel label17;
    private javax.swing.JLabel label18;
    private javax.swing.JLabel label19;
    private javax.swing.JLabel label2;
    private javax.swing.JLabel label20;
    private javax.swing.JLabel label21;
    private javax.swing.JLabel label22;
    private javax.swing.JLabel label23;
    private javax.swing.JLabel label24;
    private javax.swing.JLabel label25;
    private javax.swing.JLabel label26;
    private javax.swing.JLabel label27;
    private javax.swing.JLabel label28;
    private javax.swing.JLabel label29;
    private javax.swing.JLabel label3;
    private javax.swing.JLabel label30;
    private javax.swing.JLabel label31;
    private javax.swing.JLabel label32;
    private javax.swing.JLabel label33;
    private javax.swing.JLabel label34;
    private javax.swing.JLabel label35;
    private javax.swing.JLabel label36;
    private javax.swing.JLabel label37;
    private javax.swing.JLabel label38;
    private javax.swing.JLabel label39;
    private javax.swing.JLabel label4;
    private javax.swing.JLabel label40;
    private javax.swing.JLabel label41;
    private javax.swing.JLabel label42;
    private javax.swing.JLabel label5;
    private javax.swing.JLabel label6;
    private javax.swing.JLabel label7;
    private javax.swing.JLabel label8;
    private javax.swing.JLabel label9;
    private javax.swing.JLabel label_c1;
    private javax.swing.JLabel label_c10;
    private javax.swing.JLabel label_c11;
    private javax.swing.JLabel label_c12;
    private javax.swing.JLabel label_c13;
    private javax.swing.JLabel label_c14;
    private javax.swing.JLabel label_c15;
    private javax.swing.JLabel label_c16;
    private javax.swing.JLabel label_c17;
    private javax.swing.JLabel label_c18;
    private javax.swing.JLabel label_c19;
    private javax.swing.JLabel label_c2;
    private javax.swing.JLabel label_c20;
    private javax.swing.JLabel label_c21;
    private javax.swing.JLabel label_c22;
    private javax.swing.JLabel label_c23;
    private javax.swing.JLabel label_c24;
    private javax.swing.JLabel label_c25;
    private javax.swing.JLabel label_c26;
    private javax.swing.JLabel label_c27;
    private javax.swing.JLabel label_c28;
    private javax.swing.JLabel label_c29;
    private javax.swing.JLabel label_c3;
    private javax.swing.JLabel label_c30;
    private javax.swing.JLabel label_c31;
    private javax.swing.JLabel label_c32;
    private javax.swing.JLabel label_c33;
    private javax.swing.JLabel label_c34;
    private javax.swing.JLabel label_c35;
    private javax.swing.JLabel label_c36;
    private javax.swing.JLabel label_c37;
    private javax.swing.JLabel label_c38;
    private javax.swing.JLabel label_c39;
    private javax.swing.JLabel label_c4;
    private javax.swing.JLabel label_c40;
    private javax.swing.JLabel label_c41;
    private javax.swing.JLabel label_c42;
    private javax.swing.JLabel label_c5;
    private javax.swing.JLabel label_c6;
    private javax.swing.JLabel label_c7;
    private javax.swing.JLabel label_c8;
    private javax.swing.JLabel label_c9;
    private javax.swing.JLabel label_calendario;
    private javax.swing.JLabel label_cirulo;
    private javax.swing.JLabel label_comentario;
    private javax.swing.JLabel label_domingo;
    private javax.swing.JLabel label_flecha;
    private javax.swing.JLabel label_jueves;
    private javax.swing.JLabel label_lunes;
    private javax.swing.JLabel label_lupa;
    private javax.swing.JLabel label_martes;
    private javax.swing.JLabel label_mes;
    private javax.swing.JLabel label_miercoles;
    private javax.swing.JLabel label_num_notificaciones;
    private javax.swing.JLabel label_sabado;
    private javax.swing.JLabel label_tareas_pendientes;
    private javax.swing.JLabel label_viernes;
    private javax.swing.JPanel panel1;
    private javax.swing.JPanel panel10;
    private javax.swing.JPanel panel11;
    private javax.swing.JPanel panel12;
    private javax.swing.JPanel panel13;
    private javax.swing.JPanel panel14;
    private javax.swing.JPanel panel15;
    private javax.swing.JPanel panel16;
    private javax.swing.JPanel panel17;
    private javax.swing.JPanel panel18;
    private javax.swing.JPanel panel19;
    private javax.swing.JPanel panel2;
    private javax.swing.JPanel panel20;
    private javax.swing.JPanel panel21;
    private javax.swing.JPanel panel22;
    private javax.swing.JPanel panel23;
    private javax.swing.JPanel panel24;
    private javax.swing.JPanel panel25;
    private javax.swing.JPanel panel26;
    private javax.swing.JPanel panel27;
    private javax.swing.JPanel panel28;
    private javax.swing.JPanel panel29;
    private javax.swing.JPanel panel3;
    private javax.swing.JPanel panel30;
    private javax.swing.JPanel panel31;
    private javax.swing.JPanel panel32;
    private javax.swing.JPanel panel33;
    private javax.swing.JPanel panel34;
    private javax.swing.JPanel panel35;
    private javax.swing.JPanel panel36;
    private javax.swing.JPanel panel37;
    private javax.swing.JPanel panel38;
    private javax.swing.JPanel panel39;
    private javax.swing.JPanel panel4;
    private javax.swing.JPanel panel40;
    private javax.swing.JPanel panel41;
    private javax.swing.JPanel panel42;
    private javax.swing.JPanel panel5;
    private javax.swing.JPanel panel6;
    private javax.swing.JPanel panel7;
    private javax.swing.JPanel panel8;
    private javax.swing.JPanel panel9;
    private javax.swing.JPanel panel_actividad;
    private javax.swing.JPanel panel_completo;
    // End of variables declaration//GEN-END:variables
}
