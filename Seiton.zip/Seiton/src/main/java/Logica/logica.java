package Logica;

import Vistas.InicioSesion;
import java.awt.Dimension;
import java.awt.Image;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JButton;

/* @author Samuel Chamizo González*/

public class logica {
    
    
    //Coloca la imagen del topo en el botón
    public static void poneImagenBoton(JButton boton, String ruta, String opcion) throws MalformedURLException, IOException
    {
        //Guarda la ruta del fichero.
        URL url = new URL(ruta);
        //Lo guarda en un objeto de tipo imagen.
        Image image = ImageIO.read(url);
        //Crea el objeto en forma de icono, que contiene el fichero de la imagen.
        ImageIcon icono = new ImageIcon(image); 
        //Pasa del fichero icono a un objeto tipo imagen para poder reescalarlo.
        Image imagen = icono.getImage();
        //Escala la imagen para poder darle el tamaño del label
        Image imagenEscalada=imagen.getScaledInstance(15, 15, Image.SCALE_SMOOTH);
        //Guarda el icono rescalado.
        ImageIcon iconoEscalado = new ImageIcon(imagenEscalada);
        //Usa el icono reescalado para el label
        boton.setIcon(iconoEscalado); 
    }
    
    //Funión que escala la imagen respetando la relación de aspecto. Se le pasa el tamaño original y el tamaño final
    public static Dimension escalaImagen(Dimension dim_original, Dimension dim_final)
    {
        int original_width = dim_original.width; 
        int original_height = dim_original.height; 
        int final_width = dim_final.width; 
        int final_height = dim_final.height; 
        int nueva_width = original_width; 
        int nueva_height = original_height; 

        //Se verifica si necesitamos escalar el ancho
        if (original_width > final_width) { 
        //Escala el ancho para ajustar 
        nueva_width = final_width; 
        //Escala la altura para mantener la relación de aspecto
        nueva_height = (nueva_height * original_height) / original_width; } 

        //Se verifica si necesitamos escalar con la nueva altura
        if (nueva_height > final_height) { 
        //Se escala la altura
        nueva_height = final_height; 
        //Se escala el ancho para mantener la relación de aspecto
        nueva_width = (nueva_height * original_width) / original_height; } 
        return new Dimension(nueva_width, nueva_height);
    }
    
    //Coloca la imagen dentro del label pasado por parámetro
    public static void poneImagenLabel(JLabel cuadro, String ruta) throws MalformedURLException, IOException
    {
        //Guarda la ruta del fichero.
        URL url = new URL(ruta);
        //Lo guarda en un objeto de tipo imagen.
        Image image = ImageIO.read(url);
        //Crea el objeto en forma de icono, que contiene el fichero de la imagen.
        ImageIcon icono = new ImageIcon(image); 
        //Pasa del fichero icono a un objeto tipo imagen para poder reescalarlo.
        Image imagen = icono.getImage();
        //Escala la imagen para poder darle el tamaño del label
        Image imagenEscalada = imagen.getScaledInstance(cuadro.getWidth(),cuadro.getHeight() ,Image.SCALE_SMOOTH);   
        //Guarda el icono rescalado.
        ImageIcon iconoEscalado = new ImageIcon(imagenEscalada);
        //Usa el icono reescalado para el label
        cuadro.setIcon(iconoEscalado); 
    }
    
    //Coloca la imagen manteniendo la relación de aspecto dentro del label pasado por parámetro
    public static void poneImagenLabelBBDD(JLabel cuadro, Image imagen) throws MalformedURLException, IOException
    {
        //Dimensión original de la imagen
        Dimension dim_original = new Dimension(imagen.getWidth(null),imagen.getHeight(null));  
        //Dimensión del cuiadro con la imagen escalada
        Dimension dim_final = new Dimension(escalaImagen(dim_original, cuadro.size()));
                
        //Escala la imagen para poder darle el tamaño del label
        Image imagenEscalada = imagen.getScaledInstance(dim_final.width,dim_final.height, Image.SCALE_SMOOTH);   
        //Guarda el icono rescalado.
        ImageIcon iconoEscalado = new ImageIcon(imagenEscalada);
        //Usa el icono reescalado para el label
        cuadro.setIcon(iconoEscalado); 
    }
    
    //Se le pasa un mes en formato numérico y te devuelve el nombre corresponda
    public static String devuelveMes(int mes){
        String resultado="";
        
        switch (mes) {
            case 1:
                resultado = "Enero";
                break;
            case 2:
                resultado = "Febrero";
                break;
            case 3:
                resultado = "Marzo";
                break;
            case 4:
                resultado = "Abril";
                break;
            case 5:
                resultado = "Mayo";
                break;
            case 6:
                resultado = "Junio";
                break;
            case 7:
                resultado = "Julio";
                break;
            case 8:
                resultado = "Agosto";
                break;
            case 9:
                resultado = "Septiembre";
                break;
            case 10:
                resultado = "Octubre";
                break;
            case 11:
                resultado = "Noviembre";
                break;
            case 12:
                resultado = "Diciembre";
                break;
        }
        return resultado;
    }
    
    //Devuelve el mes actual
    public static String devuelveMesAcutal(){
        //Formato de fecha
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-01");
        int mes = Integer.parseInt(dtf.format(LocalDateTime.now()).split("-")[1]);
       
        return devuelveMes(mes);
    }
    
    //Devuelve el número de días que tiene el mes pasado por parámetro
    public static int numeroDiasMes(int mes)
    {
        int resultado=0;
        switch (mes) {
            case 1:
                resultado = 31;
                break;
            case 2:
                resultado = 28;
                break;
            case 3:
                resultado = 31;
                break;
            case 4:
                resultado = 30;
                break;
            case 5:
                resultado = 31;
                break;
            case 6:
                resultado = 30;
                break;
            case 7:
                resultado = 31;
                break;
            case 8:
                resultado = 31;
                break;
            case 9:
                resultado = 30;
                break;
            case 10:
                resultado = 31;
                break;
            case 11:
                resultado = 30;
                break;
            case 12:
                resultado = 31;
                break;
        }
        return resultado;
    }    
    
    
    //Devuelve el primer día del mes de tipo int
    public static int primerDiaMes(int mes, int ano){
        
        //Crea una instancia con la fecha pasada para obtener el día
        Calendar c = Calendar.getInstance();
        c.set(ano,mes-1,1); 
        int numSemana =  c.get(Calendar.DAY_OF_WEEK);
        
        //Variable que va a contener el resultado
        int diaSemana=0;
        
        switch (numSemana) {
            case Calendar.MONDAY:
                diaSemana = 1;
                break;
            case Calendar.TUESDAY:
                diaSemana = 2;
                break;
            case Calendar.WEDNESDAY:
                diaSemana = 3;
                break;
            case Calendar.THURSDAY:
                diaSemana = 4;
                break;
            case Calendar.FRIDAY:
                diaSemana = 5;
            break;
            case Calendar.SATURDAY:
                diaSemana = 6;
                break;
            case Calendar.SUNDAY:
                diaSemana = 7;
            break;
        }
        return diaSemana;
    }
    
    //Devuelve el primer día del mes de tipo String
    public static String devuelveHoy()
    {
        //Formato de fecha
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return dtf.format(LocalDateTime.now());
    }   
    
    //Envía un correo con los parámetros pasados
    public static void enviaGmail(String destinatario, String asunto, String cuerpo){
    
        //Configura las propiedades del correo
        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true"); //TLS
        
        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication("equiposeiton@gmail.com", "orloqsqnappzwkdo");
                        //return new PasswordAuthentication("scg769@gmail.com", "kfunmwhdcustasns");
                    }
                });
        try {
 
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("from@gmail.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario)); //Destinatario
            message.setSubject(asunto); //Asunto
            message.setText(cuerpo); //Cuerpo
            Transport.send(message);
  
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    } 
    
    //Biblioteca que guarda diferentes mensajes que se envían automáticamente con ciertas funcionalidades del programa
    public static String mensajes(String destinatario, String tarea, String opcion){
        
        String mensaje="";
        switch(opcion)
        {
            case "pregunta":
                mensaje=new String("Buenas "+destinatario+",\n\n"
                        + "Nos ponemos en contacto con usted para informarle de que el usuario '"+InicioSesion.nombreUsuario+"' quiere compartir una tarea contigo llamada  '"+tarea+"' contigo. Por favor, inicie sesión en el programa para responder a la petición.\n\n"
                        + "Gracias por confiar en Seiton, mantente ordenado :)");
                break;
                
            case "respuestaPositiva":
                mensaje=new String(
                        "Buenas "+destinatario+",\n\n"
                        + "Nos ponemos en contacto con usted para informarle que el usuario '"+InicioSesion.nombreUsuario+"' ha aceptado la petición para compartir la tarea '"+tarea+"'.\n\n" 
                        + "Nos alegra mucho ver que cada día apoyamos y confiamos más en nuestros compañeros. Desde luego así da alegría compartir conocimientos y habilidades.\n\n"
                        + "Gracias por confiar en Seiton, mantente ordenado :)");
                break;
                
            case "respuestaNegativa":
                mensaje=new String(
                        "Buenas "+destinatario+",\n\n"
                        + "Nos ponemos en contacto con usted para informarle que el usuario '"+InicioSesion.nombreUsuario+"' ha denegado la petición para compartir la tarea '"+tarea+"'.\n\n"
                        + "Entendemos que son fechas complicadas para todos, quizá en otro momento podáis compartir conocimiento o habilidades. \n\n" 
                        + "Gracias por confiar en Seiton, mantente ordenado :)");
                break;
        }
        return mensaje;
    }
}


