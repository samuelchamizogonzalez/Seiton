
package Hilos;

import Logica.logica;

/* @author Samuel Chamizo González*/

public class HiloEnviaMensaje extends Thread{
    
    private final String destinatario;
    private final String asunto;
    private final String mensaje;
    
    public HiloEnviaMensaje(String destinatario, String asunto, String mensaje)
    {
        this.destinatario=destinatario;
        this.asunto=asunto;
        this.mensaje=mensaje;
    }
    
    @Override
    public void run() { 
        
        try
        {
            //Envia un correo con la información proporcionada
            logica.enviaGmail(this.destinatario, this.asunto, this.mensaje);
            System.out.println("Se ha enviado el mensaje a "+this.destinatario);
            this.stop(); //Para el hilo
        }
        catch(Exception e){
            System.err.println(e);} 
    }
}
